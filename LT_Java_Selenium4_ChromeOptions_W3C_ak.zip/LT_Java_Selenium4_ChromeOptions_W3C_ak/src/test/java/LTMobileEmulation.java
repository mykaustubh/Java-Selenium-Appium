import java.net.URI;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

// import org.openqa.selenium.remote.RemoteWebDriver;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;

public class LTMobileEmulation {
        public static final String USERNAME = "kaustubhd";
        public static final String ACCESS_KEY = "8HvZgofk5sGPes4rbhRC986qrrg2HWhxsQxE";
        public static final String platformVersion = "16";
        public static final String bundleID = "com.salesforce.chatter";

        public static void main(String[] args) throws Exception {

                DesiredCapabilities chromeOptions = new DesiredCapabilities();
                // chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
                // chromeOptions.setCapability(ChromeOptions.CAPABILITY, chromeOptions);

                // chromeOptions.setCapability("browserName", "Chrome");
                HashMap<String, Object> ltOptions = new HashMap<String, Object>();
                ltOptions.put("w3c", "true");
                // ltOptions.put("network", true);
                // ltOptions.put("network.har", true);
                ltOptions.put("platformName", "ios");
                ltOptions.put("deviceName", "iPhone 14.*");
                ltOptions.put("build", "Signin Error");
                ltOptions.put("platformVersion", platformVersion);
                ltOptions.put("test", "TestSigma");
                ltOptions.put("isRealMobile", true);
                ltOptions.put("app", "lt://APP10160291931718798154222896");
                ltOptions.put("appium:animationCoolOffTimeout", 1);
                // ltOptions.put("appiumVersion", "2.2.1");
                // ltOptions.put("device_viewport", "448 x 998");
                ltOptions.put("devicelog", true);
                // ltOptions.put("bundleID", bundleID);
                // ltOptions.put("showIOSLog", true);
                // ltOptions.put("autoLaunch", false);
                // ltOptions.put("autoAcceptAlerts", false);
                // ltOptions.put("privateCloud", true);
                ltOptions.put("visual", true);
                // ltOptions.put("nativeWebScreenshot", true);
                // ltOptions.put("resolution", "1344 x 2992 px");
                ltOptions.put("idleTimeout", "900");

                chromeOptions.setCapability("lt:Options", ltOptions);

                // chromeOptions.setCapability("idleTimeout", 900);

                // Tunnel t = new Tunnel();
                // HashMap<String, String> options = new HashMap<String, String>();
                // options.put("user", USERNAME);
                // options.put("key", ACCESS_KEY);
                // Thread.sleep(100000);
                //
                // t.start(options);
                // Thread.sleep(100000);

                URI uri = new URI(
                                "https://" + USERNAME + ":" + ACCESS_KEY + "@mobile-hub-mumbai.lambdatest.com/wd/hub");
                URL LT_GRID_URL = uri.toURL();
                AndroidDriver driver = new AndroidDriver(LT_GRID_URL, chromeOptions); // AndroidDriver driver = new
                                                                                      // AndroidDriver(new
                                                                                      // URL(LT_GRID_URL),
                                                                                      // chromeOptions);
                Thread.sleep(30000);
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

                // driver.activateApp(appId);

                // // Example of setting values
                // Map<String, Object> settings = new HashMap<>();
                // settings.put("mjpegServerFramerate", 15); // Set mjpegServerFramerate to 15
                // settings.put("screenshotQuality", 1); // Set screenshotQuality to 1
                // settings.put("elementResponseAttributes", "type,label"); // Set
                // elementResponseAttributes

                driver.setSetting("animationCoolOffTimeout", 1);
                driver.setSetting("shouldUseCompactResponses", false);
                driver.setSetting("elementResponseAttributes", "type,label");

                // Retrieve the current settings to verify
                Map<String, Object> currentSettings = driver.getSettings();
                System.out.println(currentSettings);

                // driver.get("https://www.teknosa.com");
                // Thread.sleep(10000000);

                // SessionId id = driver.getSessionId();
                // System.out.println(id);

                // Create a TouchAction instance
                // TouchAction action = new TouchAction(driver);

                // // Perform a long press
                // action.longPress(LongPressOptions.longPressOptions()
                // .withElement(ElementOption.element(loginBtn))
                // .withDuration(Duration.ofSeconds(2)))
                // .release()
                // .perform();

                WebElement el1 = driver.findElement(
                                AppiumBy.id("com.android.permissioncontroller:id/permission_allow_button"));
                el1.click();
                WebElement el2 = driver.findElement(
                                AppiumBy.xpath("//android.widget.Button[@content-desc=\"Open a business account\"]"));
                el2.click();
                // WebElement el5 =
                // driver.findElement(AppiumBy.className("android.widget.Button"));
                WebElement el5 = driver.findElement(AppiumBy.xpath(
                                "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.Button"));
                el5.sendKeys("gf@gmail.com\\n");
                Thread.sleep(30000);

                // WebElement el6 =
                // driver.findElement(AppiumBy.className("android.widget.EditText"));
                WebElement el6 = driver.findElement(AppiumBy.xpath(
                                "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
                el6.click();
                el6.sendKeys("7777777777");
                WebElement el7 = driver.findElement(AppiumBy.accessibilityId("Continue"));
                el7.click();
                Thread.sleep(30000);

                // driver.activateApp("bundleId"); // pass your app's package name here
                // HashMap paramsRotate = new HashMap();
                // paramsRotate.put("command", "autorotate");
                // paramsRotate.put("enableAutoRotate", false);
                // driver.executeScript("lambda-adb", paramsRotate);
                // ((JavascriptExecutor) driver).executeScript("lambda-testCase-start=Start
                // Paytm");

                // WebDriver driver = DriverManager.getDriver();
                // Map<String, Object> data = new HashMap<>();
                // data.put("text", "dumpsys package net.one97.paytm");
                // JavascriptExecutor jse = (JavascriptExecutor) driver;
                // String lines = (String) jse.executeScript("lambda-adb", data);

                // if (platformVersion.equals("14")) {
                // WebElement element = driver.findElement(AppiumBy.xpath(
                // "//XCUIElementTypeOther[@name=\"ApplicatieVenster\"]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeButton"));
                // element.click();
                // } else if (platformVersion.equals("16")) {
                // WebElement element =
                // driver.findElement(AppiumBy.accessibilityId("legacy/icon/clock24"));
                // element.click();
                // }

                // ((JavascriptExecutor) driver).executeScript("lambda-testCase-end=Start
                // Paytm");

                // WebElement el1 = (WebElement)
                // driver.findElement(AppiumBy.accessibilityId("Take Picture"));

                // t.stop();
                driver.quit();
        }
}
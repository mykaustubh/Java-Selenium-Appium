This repo includes code to pass ChromeOptions with Selenium 4 and LambdaTest LT:Options.

